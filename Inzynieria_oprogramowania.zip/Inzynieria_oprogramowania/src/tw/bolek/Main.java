package tw.bolek;

import JavaMasters.IO.UsersManager;
import Project.Package.ProjectManager;
import ch.makery.shop.ITaskService;
import ch.makery.shop.TaskService;
import ch.makery.shop.model.Task;
import ch.makery.shop.P
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.List;

public class Main extends Application {

    List<String> users;
    List<String> projects;

    public void testMetod() {
        ITaskService itask = new TaskService();
        ObservableList<Task> lista = itask.getTaskList();
        for (Task task : lista) {
            System.out.println(task.getTitle());
        }
        UsersManager.getAllUsers();

        Proje


    }


    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("fxml/view.fxml"));
        primaryStage.setTitle("Inżynieria oprogramowania [tw.bolek]");
        primaryStage.setScene(new Scene(root, 900, 600));
        primaryStage.show();
        testMetod();
    }
}
