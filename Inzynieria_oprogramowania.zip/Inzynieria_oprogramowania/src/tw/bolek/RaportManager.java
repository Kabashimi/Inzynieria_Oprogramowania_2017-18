package tw.bolek;

import JavaMasters.IO.User;
import JavaMasters.IO.UsersManager;
import Project_package.ProjectManager;
import ch.makery.shop.ITaskService;
import ch.makery.shop.TaskService;
import ch.makery.shop.model.Task;
import javafx.collections.ObservableList;


/**
 * Created by Jan on 07.12.2017.
 */
public class RaportManager {

    public void main() {
        ITaskService itask = new TaskService();
        ObservableList<Task> lista = itask.getTaskList();
        for (Task task : lista) {
            System.out.println(task.getTitle());
        }
        UsersManager.getAllUsers();


        ProjectManager projectManager = new ProjectManager();
        ProjectManager proj = new ProjectManager();
        pro

    }

    private void PrepareUsersList(){
    }
}
